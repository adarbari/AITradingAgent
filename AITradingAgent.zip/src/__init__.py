"""
AI Trading Agent main package
""" 