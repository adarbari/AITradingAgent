"""
Utility functions module.
""" 